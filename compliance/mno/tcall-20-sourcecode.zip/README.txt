LGE_ADS_1.0_Packaging/

| CDDL 1.0/
| | javax.servlet-api

| CDDL 1.1/ 
| | JavaBeans Activation Framework API JAR
| | javax.annotation-api
| | javax.transaction-api
| | jaxb
| | jaxb-impl
| | Old JAXB Core

| EPL 1.0/ 
| | AspectJ Weaver
| | ecj
| | logback-classic
| | logback-core

| LGPL 2.1/ 
| | FindBugs Annotations
| | Hibernate Commons Annotations

| MPL 1.1/
| | javassist


