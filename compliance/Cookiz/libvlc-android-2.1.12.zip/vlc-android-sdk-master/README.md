vlc-android-sdk
===============

Unofficial VLC Android SDK pushed to JCenter.
Supported ABIs are armeabi-v7a, arm64-v8a, x86 and x86_64.
                              
Reporting issues
------------------------
Please contact the videolan team directly. I am only publishing LibVLC for Android JCenter.

https://trac.videolan.org/vlc

Get it via JCenter
------------------------
Just add this dependency to your project and you're good to go.

<pre>repositories {
    jcenter()
}
dependencies {
    compile 'de.mrmaffen:libvlc-android:2.1.12@aar'
}</pre>
