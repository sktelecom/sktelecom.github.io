import XCTest

import SwiftIcalTests

var tests = [XCTestCaseEntry]()
tests += SwiftIcalTests.allTests()

XCTMain(tests)
