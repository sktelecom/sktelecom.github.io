## Toolchain

- Platform Toolset: Visual Studio 2019 (v142)
- Target Platform: x64

## How to build

MSBuild is installed in the \Current folder under each version of Visual Studio, and the executables are in the \Bin subfolder. For example, the path to MSBuild.exe installed with Visual Studio 2019 Community is C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\MSBuild\Current\Bin\MSBuild.exe

$ MSBuild.exe .\libhangul\Win\libhangulWin\libhangulWin.vcxproj /p:Configuration=Release /p:Platform=x64 /t:Build
